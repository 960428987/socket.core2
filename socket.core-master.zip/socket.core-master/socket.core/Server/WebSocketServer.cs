﻿using System;
using System.Collections.Generic;
using System.Text;

namespace socket.core.Server
{
    /// <summary>
    /// WebSocket
    /// </summary>
    public class WebSocketServer
    {

    }
}
